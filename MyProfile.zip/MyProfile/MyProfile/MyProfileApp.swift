//
//  MyProfileApp.swift
//  MyProfile
//
//  Created by IACD Training 4 on 2024/05/03.
//

import SwiftUI

@main
struct MyProfileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
