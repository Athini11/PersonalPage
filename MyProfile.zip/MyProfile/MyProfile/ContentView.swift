//
//  ContentView.swift
//  MyProfile
//
//  Created by IACD Training 4 on 2024/05/03.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            TabView{
                Home()
                    .tabItem {
                            Label("Home", systemImage: "house")
                    }
                
                Skills()
                    .tabItem {
                        Label("Skills", systemImage: "list.bullet")
                    }
                Contacts()
                    .tabItem {
                        Label("Contacts", systemImage: "person.bubble")
                    }
            }
           
        }
       

    }
}

#Preview {
    ContentView()
}
