//
//  Contacts.swift
//  MyProfile
//
//  Created by IACD Training 4 on 2024/05/03.
//

import SwiftUI

struct Contacts: View {
    var body: some View {
        NavigationView {
            VStack{
                NavigationLink(destination: Home()) {
                    Image(systemName: "chevron.backward")
                    Text("Back")
                }
                .offset(x:-130)
                
                
                Text("Contacts")
                    .font(.system(size: 28))
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    .padding()
                 
                Text("Email: hey@gmail.com")
                    .padding(3)
                Text("Tel: 0000000000")
                    .padding(3)
                Text("Address: 11 Surrey Ave, Ferndale")
                
                
                
                Spacer()
            }
        }
    }
}

#Preview {
    Contacts()
}
