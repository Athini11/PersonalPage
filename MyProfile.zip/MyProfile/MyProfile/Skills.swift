//
//  Skills.swift
//  MyProfile
//
//  Created by IACD Training 4 on 2024/05/03.
//

import SwiftUI

struct Skills: View {
    var body: some View {
        NavigationView {
            VStack{
            NavigationLink(destination: Home()) {
                Image(systemName: "chevron.backward")
                Text("Back")
                 }
            .offset(x:-130, y: 10)
                
                Text("Skills")
                    .font(.system(size: 26))
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    .padding()
                Spacer()
                
                List {
                    
                    Text("Wireframing")
                    Text("User Research")
                    Text("Javascript")
                    Text("Software Testing")
                    Text("Interaction Design")
                }
                
                
                
            }
        }
        
    }
}

#Preview {
    Skills()
}
