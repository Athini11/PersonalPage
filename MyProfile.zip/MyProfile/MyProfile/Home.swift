//
//  Home.swift
//  MyProfile
//
//  Created by IACD Training 4 on 2024/05/03.
//

import SwiftUI

struct Home: View {
    var body: some View {
        VStack{
            Text("Athini Mashumi")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(.system(size: 36))
                .padding()
            
            Image("profile")
                .resizable()
                .frame(width: 300,height: 300)
                .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                .padding()
            
            Text("I'm a **UX/UI Designer** Intern at Mpilo Technologies, my job is about creating wireframes and prototypes. I'm working closely with developers to finalise the overall look and functionality. ")
                .font(.system(size: 19))
                .multilineTextAlignment(.center)
                .lineSpacing(/*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/)
                .padding()
            
          
            Spacer()
           

          
        }
        .padding()
        
        
       
     
    }
}

#Preview {
    Home()
}
